


public class Employee {
	
	int id;
	String name;
	int salery;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getsalery(){
		return salery;
	}
	public void setsalery(){
		this.salery = salery;
	}
	
	

}
